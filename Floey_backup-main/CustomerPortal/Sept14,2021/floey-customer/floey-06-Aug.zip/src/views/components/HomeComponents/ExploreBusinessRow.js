import React, { useEffect, useState } from "react";
import Cookies from 'universal-cookie';
import axios from 'axios';
import BASE_URL from "../../pages/base";

const cookies = new Cookies();

function ExploreBusinessRow(props) {

const [usergyms,selectedgym] = useState([])
const [getgym,setgym] = useState([])
const [selectedgymids, SelectedIds] = useState([])
// var data='agvdhsv';
useEffect(() => {
    axios
    .get(BASE_URL + 'user/select/gym/?uuid='+cookies.get('uuid'))
    .then(res => {
      console.log(res)
      // debugger
      selectedgym(res.data.context)
      SelectedIds(res.data.uuids)
    })
    .catch(err => {
      // console.log(err)
    })
  }, [])


useEffect(() => {
    axios
    .get(BASE_URL + 'gymprofile/')
    .then(res => {
      console.log(res)
      console.log(cookies.get('email'));
      setgym(res.data);
      // data2 = setgym(res.data);
      console.clear()
      console.log(res.data)
    })
    .catch(err => {
      // console.log(err)
    })
  }, [])

  
  async function SelectGym(data) {
    
    // debugger

    // console.log(data)
    try {
        console.log('Trying');
        let res = await axios.post(BASE_URL + 'user/select/gym/', {
          
            gym_user: cookies.get('uuid'),
            gym: data,
        })
       if (res.status === 200) {
          // debugger
          console.log(res.data)
          window.location.reload();
        }
      }
      catch (err) {
        console.error(err);
          alert('Login unsuccessfull.');
          window.location = '#/Login';
      }
    }
    
  const [TotalAdd, setTotalAdd] = useState(0);
  function ChangeValue(e,uuid){
    HandleAddedButton(e);
    SelectGym(uuid)
  }
  const HandleAddedButton = (e) => {
    let TotalItem = 0;
    
    // SelectGym(data.gym_name);
    // alert(data.gym_name);
    if (e.target.textContent == "ADD") {
      TotalItem = TotalItem + 1;
      e.target.textContent = "ADDED";
      // alert(e.target.value)
      // SelectGym(e.target.value); 
      
      window.sessionStorage.setItem("added-amount", TotalItem);
    } else {
      TotalItem = TotalItem - 1;
      e.target.textContent = "ADD";
      window.sessionStorage.setItem("added-amount", TotalItem);
    }
  };
  return (
    <>
    {getgym.map(data=>{
      {/* alert(data.gender_criteria) */}

      if(cookies.get('gender')===data.gender_criteria || data.gender_criteria==='Unisex'){
        
   return <div className="explore-row">
      <div className="explore-col-1">
      {data.gym_image && <img src={BASE_URL.slice(0,-1)+ data.gym_image} alt="image" />}
      
      </div>
      
      <div className="explore-col-2">
        <h4>{data.gym_name}</h4>
        <span>
        {data.about}
        </span>
      </div>

        <div className="exlpore-col-4">
        {/* <span>Offering Classes & PT</span> */}
        <span className="exlpore-col-4-heading">Address</span>
        <span>{data.address}</span>
       
        <span className="exlpore-col-4-heading">Gender</span>
        <span> {data.gender_criteria}({data.age_criteria})</span>
        {/* <span>Shuwaikh Mayar Complex</span> */}
        
      </div>
      <div className="exlpore-col-4">
        <span className="exlpore-col-4-heading">Hours</span>
        <span>{data.gym_timings}</span>
        <span className="exlpore-col-4-heading">Tel</span>
        <span>{data.contact_number}</span>
      </div>

      <div className="exlpore-col-5">

    
    {selectedgymids.includes(data.uuid)?<div><input checked disabled type="checkbox" id={`checkbox-${data.uuid}`} /><label for={`checkbox-${data.uuid}`} 
    >
      ADDED
    </label></div>:<div><input type="checkbox" id={`checkbox-${data.uuid}`} /><label for={`checkbox-${data.uuid}`} 
    onClick={(e)=>ChangeValue(e,data.uuid)}>
      ADD
    </label></div>}
      </div>
</div>
    
  }

})}

    </>
    
  );
}
    
{/* 
        <button class="btn-add "> 
            <span onClick={()=>SelectGym(data)}>ADD</span>
        </button> */}


        {/* <button onClick={HandleAddedButton}>ADD</button> */}


// <label for={`checkbox-${props._id}`} onClick={() => {
  //   SelectGym(data);
  //   HandleAddedButton();
  // }}>


export default ExploreBusinessRow;
