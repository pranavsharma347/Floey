import React from "react";

function DashboardHistory() {
    return <div className = "DashboardHistory" > </div>;
}

export default DashboardHistory;