export const HandleSidebar = (element) => {
  document.querySelector(".HomeSideBar").classList.toggle("active-sidebar");
};
