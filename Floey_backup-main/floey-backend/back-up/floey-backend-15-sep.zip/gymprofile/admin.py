from django.contrib import admin
from .models import *
# Register your models here.


from django.contrib import admin


admin.site.register(GymProfile)
admin.site.register(Packages)
admin.site.register(Instructor)
admin.site.register(Weekdays)
admin.site.register(Course)
admin.site.register(Classes)
admin.site.register(Online)
admin.site.register(GymTime)
admin.site.register(Location)
admin.site.register(Holiday)
# admin.site.register(Membership)
admin.site.register(Age_Group)
admin.site.register(CancellationPolicy)
admin.site.register(Ammenities)
admin.site.register(Transaction)