from django.apps import AppConfig


class GymprofileConfig(AppConfig):
    name = 'gymprofile'
